class ChildRules:
	def __init__(self):
		a=1

	def havekid(self,creature,max_size,min_size,kid_size,kid_stomach_size,safty):
		alist = []
		return alist
		
