class Foodsystem:

	def __init__(self):
		a=1

	def addFood(self,amount):
		a = []
		a.append((0,0,amount))
		return a

	def addLargeFood(self,amount):
		return addFood(amount)
