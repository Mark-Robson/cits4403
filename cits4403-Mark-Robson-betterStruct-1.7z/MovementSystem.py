
class MovementSystem:

	def __init__(self):
		a = 0
#returns (x,y) to move to
	def move (self,creature,speed,data):
		return creature.x,creature.y
